package com.h4ll0.recorder

import android.content.Context
import android.widget.Toast
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.*
import androidx.camera.view.PreviewView
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import java.io.File

private val Red = Color(0xFFE0262E)

@Composable
fun CameraScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember { PreviewView(context) }
    var isVideoMode by remember { mutableStateOf(false) }
    var isRecording by remember { mutableStateOf(false) }
    var lensFacing by remember { mutableStateOf(CameraSelector.LENS_FACING_BACK) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }
    var videoCapture by remember { mutableStateOf<VideoCapture<Recorder>?>(null) }
    var activeRecording by remember { mutableStateOf<Recording?>(null) }

    fun toast(t: String) = Toast.makeText(context, t, Toast.LENGTH_SHORT).show()

    fun bindCamera() {
        val future = ProcessCameraProvider.getInstance(context)
        future.addListener({
            val provider = future.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val imgCap = ImageCapture.Builder().build()
            val recorder = Recorder.Builder().setQualitySelector(QualitySelector.from(Quality.HD)).build()
            val vidCap = VideoCapture.withOutput(recorder)
            val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            provider.unbindAll()
            try {
                provider.bindToLifecycle(lifecycleOwner, selector, preview, imgCap, vidCap)
                imageCapture = imgCap
                videoCapture = vidCap
            } catch (e: Exception) { toast("Gagal buka kamera: ${e.message}") }
        }, ContextCompat.getMainExecutor(context))
    }

    LaunchedEffect(lensFacing) { bindCamera() }

    fun takePhoto() {
        val ic = imageCapture ?: return
        val file = File(FilesUtil.photosDir(context), "IMG_${System.currentTimeMillis()}.jpg")
        val out = ImageCapture.OutputFileOptions.Builder(file).build()
        ic.takePicture(out, ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(r: ImageCapture.OutputFileResults) = toast("Foto tersimpan")
            override fun onError(e: ImageCaptureException) = toast("Gagal: ${e.message}")
        })
    }

    fun stopVideo() { activeRecording?.stop(); activeRecording = null; isRecording = false }

    fun startVideo() {
        val vc = videoCapture ?: return
        val file = File(FilesUtil.videosDir(context), "VID_${System.currentTimeMillis()}.mp4")
        val outOpts = FileOutputOptions.Builder(file).build()
        val hasAudio = ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED
        var pending = vc.output.prepareRecording(context, outOpts)
        if (hasAudio) pending = pending.withAudioEnabled()
        activeRecording = pending.start(ContextCompat.getMainExecutor(context)) { event ->
            if (event is VideoRecordEvent.Finalize) {
                isRecording = false
                toast(if (!event.hasError()) "Video tersimpan" else "Gagal rekam: kode ${event.error}")
            }
        }
        isRecording = true
    }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            AndroidView({ previewView }, Modifier.fillMaxSize())
            if (isRecording) Text("● REC", color = Red, modifier = Modifier.padding(12.dp))
        }
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            TextButton({ lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK }) { Text("🔄") }
            Button({
                if (isVideoMode) { if (isRecording) stopVideo() else startVideo() } else takePhoto()
            }, colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                Text(if (isVideoMode) (if (isRecording) "Stop" else "● Rekam") else "📷 Foto")
            }
            TextButton({ if (!isRecording) isVideoMode = !isVideoMode }) { Text(if (isVideoMode) "Mode: Video" else "Mode: Foto") }
        }
    }
}
