package com.h4ll0.recorder

import android.content.Context
import java.io.File

object FilesUtil {
    fun photosDir(c: Context) = File(c.getExternalFilesDir(null), "photos").apply { mkdirs() }
    fun videosDir(c: Context) = File(c.getExternalFilesDir(null), "videos").apply { mkdirs() }
    fun audioDir(c: Context) = File(c.getExternalFilesDir(null), "audio").apply { mkdirs() }

    fun allMedia(c: Context): List<File> {
        val all = (photosDir(c).listFiles().orEmpty() + videosDir(c).listFiles().orEmpty() + audioDir(c).listFiles().orEmpty())
        return all.sortedByDescending { it.lastModified() }
    }
}
