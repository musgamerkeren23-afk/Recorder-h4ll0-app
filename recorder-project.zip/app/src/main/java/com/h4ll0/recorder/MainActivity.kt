package com.h4ll0.recorder

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

private val Red = Color(0xFFE0262E)
private val PERMS = if (Build.VERSION.SDK_INT >= 33)
    arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
else arrayOf(Manifest.permission.RECORD_AUDIO)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Color(0xFF0D0A0A), surface = Color(0xFF191212))) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }
}

@Composable
fun App() {
    val context = LocalContext.current
    fun granted() = PERMS.all { ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED }
    var ok by remember { mutableStateOf(granted()) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ok = granted() }
    var tab by remember { mutableStateOf(0) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text("Recorder H4ll0", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Red, modifier = Modifier.padding(12.dp))
        if (!ok) {
            Column(Modifier.fillMaxSize().padding(24.dp)) {
                Text("Butuh izin mic buat mulai.")
                Spacer(Modifier.height(10.dp))
                Button({ launcher.launch(PERMS) }) { Text("Izinkan") }
            }
            return@Column
        }
        TabRow(selectedTabIndex = tab) {
            Tab(tab == 0, { tab = 0 }, text = { Text("Layar") })
            Tab(tab == 1, { tab = 1 }, text = { Text("Mic") })
            Tab(tab == 2, { tab = 2 }, text = { Text("Galeri") })
        }
        when (tab) { 0 -> ScreenRecordScreen(); 1 -> MicScreen(); else -> GalleryScreen() }
    }
}
