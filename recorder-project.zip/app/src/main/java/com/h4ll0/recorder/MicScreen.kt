package com.h4ll0.recorder

import android.media.MediaRecorder
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

private val Red = Color(0xFFE0262E)

@Composable
fun MicScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recording by remember { mutableStateOf(false) }
    var seconds by remember { mutableStateOf(0) }
    fun toast(t: String) = Toast.makeText(context, t, Toast.LENGTH_SHORT).show()

    fun start() {
        val file = File(FilesUtil.audioDir(context), "AUD_${System.currentTimeMillis()}.m4a")
        val r = (if (Build.VERSION.SDK_INT >= 31) MediaRecorder(context) else @Suppress("DEPRECATION") MediaRecorder())
        try {
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(file.absolutePath)
            r.prepare(); r.start()
            recorder = r; recording = true; seconds = 0
            scope.launch { while (recording) { delay(1000); seconds++ } }
        } catch (e: Exception) {
            toast("Mic lagi dipakai app lain, coba tutup app itu dulu")
        }
    }
    fun stop() {
        try { recorder?.stop() } catch (_: Exception) { }
        recorder?.release(); recorder = null; recording = false
        toast("Rekaman suara tersimpan")
    }

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = androidx.compose.ui.Alignment.CenterHorizontally) {
        Text(if (recording) "🎙 Merekam..." else "Siap merekam suara", fontSize = 20.sp)
        Spacer(Modifier.height(10.dp))
        val m = seconds / 60; val s = seconds % 60
        Text("%02d:%02d".format(m, s), fontSize = 40.sp)
        Spacer(Modifier.height(24.dp))
        Button({ if (recording) stop() else start() }, colors = ButtonDefaults.buttonColors(containerColor = Red)) {
            Text(if (recording) "Stop" else "Mulai Rekam")
        }
        Spacer(Modifier.height(16.dp))
        Text("Catatan: kalau app lain (game, voice call) lagi pakai mic duluan, Android kadang nolak kita ikut pakai. Ini batasan sistem, bukan bug.", color = Color.Gray, fontSize = 12.sp)
    }
}
