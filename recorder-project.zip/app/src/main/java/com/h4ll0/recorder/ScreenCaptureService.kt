package com.h4ll0.recorder

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.max

class ScreenCaptureService : Service() {
    companion object { var instance: ScreenCaptureService? = null }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var mediaRecorder: MediaRecorder? = null
    private var width = 0
    private var height = 0
    private var density = 0
    var isRecording = false
        private set

    // bubble overlay
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var menu: LinearLayout? = null
    private var menuShown = false
    var onStateChange: (() -> Unit)? = null

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        startForeground(3, notif())
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        val metrics = DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }
        width = metrics.widthPixels
        height = metrics.heightPixels
        density = metrics.densityDpi
        if (Settings.canDrawOverlays(this)) addBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("data", Intent::class.java)
            else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")
        if (resultCode == Activity.RESULT_OK && data != null) {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mgr.getMediaProjection(resultCode, data)
        }
        return START_NOT_STICKY
    }

    private fun notif(): Notification {
        val ch = "screencap"
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(ch, "Recorder H4ll0", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(c)
        }
        return NotificationCompat.Builder(this, ch)
            .setContentTitle("Recorder H4ll0 aktif")
            .setContentText("Siap merekam layar")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true).build()
    }

    // ---------- Bubble overlay ----------

    private fun overlayType() =
        if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

    private fun addBubble() {
        if (bubble != null) return
        val size = (56 * resources.displayMetrics.density).toInt()
        val b = View(this).apply {
            setBackgroundColor(Color.parseColor(if (isRecording) "#E0262E" else "#CC222222"))
        }
        val p = WindowManager.LayoutParams(
            size, size, overlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = 20; p.y = 300
        var dx = 0f; var dy = 0f; var sx = 0; var sy = 0; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; sx = p.x; sy = p.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    p.x = sx + (e.rawX - dx).toInt(); p.y = sy + (e.rawY - dy).toInt()
                    if (max(abs(e.rawX - dx), abs(e.rawY - dy)) > 12) moved = true
                    runCatching { wm.updateViewLayout(b, p) }; true
                }
                MotionEvent.ACTION_UP -> { if (!moved) toggleMenu(p) ; true }
                else -> false
            }
        }
        runCatching { wm.addView(b, p) }
        bubble = b
    }

    private fun toggleMenu(bubbleParams: WindowManager.LayoutParams) {
        if (menuShown) { menu?.let { runCatching { wm.removeView(it) } }; menu = null; menuShown = false; return }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(Color.parseColor("#DD191212")) }
        fun btn(label: String, onClick: () -> Unit) = TextView(this).apply {
            text = label; setTextColor(Color.WHITE); setPadding(28, 20, 28, 20); textSize = 13f
            setOnClickListener { onClick() }
        }
        row.addView(btn(if (isRecording) "■ Stop" else "● Rekam") {
            if (isRecording) stopRecording() else startRecording { ok, err -> if (!ok) refreshBubbleColor() }
            toggleMenu(bubbleParams); refreshBubbleColor()
        })
        row.addView(btn("📸") { takeScreenshot { _, _ -> }; toggleMenu(bubbleParams) })

        val mp = WindowManager.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT,
            overlayType(), WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        )
        mp.gravity = Gravity.TOP or Gravity.START
        mp.x = bubbleParams.x; mp.y = bubbleParams.y + (56 * resources.displayMetrics.density).toInt() + 10
        runCatching { wm.addView(row, mp) }
        menu = row; menuShown = true
    }

    private fun refreshBubbleColor() {
        bubble?.setBackgroundColor(Color.parseColor(if (isRecording) "#E0262E" else "#CC222222"))
        onStateChange?.invoke()
    }

    fun removeBubble() {
        bubble?.let { runCatching { wm.removeView(it) } }; bubble = null
        menu?.let { runCatching { wm.removeView(it) } }; menu = null
        menuShown = false
    }

    // ---------- Recording ----------

    private fun settings() = getSharedPreferences("rsettings", MODE_PRIVATE)

    fun startRecording(onDone: (Boolean, String?) -> Unit) {
        val mp = mediaProjection
        if (mp == null) { onDone(false, "Izin layar belum siap"); return }
        try {
            val prefs = settings()
            val scale = when (prefs.getString("res", "720p")) { "480p" -> 0.5f; "1080p" -> 1f; else -> 0.75f }
            val audioOn = prefs.getString("audio", "mic") != "none"
            var vw = (width * scale).toInt(); if (vw % 2 != 0) vw += 1
            var vh = (height * scale).toInt(); if (vh % 2 != 0) vh += 1

            val file = File(FilesUtil.videosDir(this), "SCR_${System.currentTimeMillis()}.mp4")
            val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            if (audioOn) rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            if (audioOn) rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setVideoSize(vw, vh)
            rec.setVideoFrameRate(30)
            rec.setVideoEncodingBitRate(8_000_000)
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            virtualDisplay = mp.createVirtualDisplay(
                "H4ll0ScreenRecord", vw, vh, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rec.surface, null, null
            )
            rec.start()
            mediaRecorder = rec
            isRecording = true
            refreshBubbleColor()
            onDone(true, null)
        } catch (e: Exception) {
            onDone(false, e.message)
        }
    }

    fun stopRecording() {
        try { mediaRecorder?.stop() } catch (_: Exception) { }
        try { mediaRecorder?.reset() } catch (_: Exception) { }
        mediaRecorder?.release(); mediaRecorder = null
        virtualDisplay?.release(); virtualDisplay = null
        isRecording = false
        refreshBubbleColor()
    }

    fun takeScreenshot(onDone: (Boolean, String?) -> Unit) {
        val mp = mediaProjection
        if (mp == null) { onDone(false, "Izin layar belum siap"); return }
        try {
            val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            val vd = mp.createVirtualDisplay(
                "H4ll0Screenshot", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, null
            )
            reader.setOnImageAvailableListener({ r ->
                val image = r.acquireLatestImage()
                if (image != null) {
                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * width
                    val bmp = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(buffer)
                    image.close()
                    val file = File(FilesUtil.photosDir(this), "SS_${System.currentTimeMillis()}.png")
                    FileOutputStream(file).use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }
                    vd.release(); reader.close()
                    onDone(true, null)
                } else {
                    vd.release(); reader.close()
                    onDone(false, "Gagal ambil gambar layar")
                }
            }, null)
        } catch (e: Exception) {
            onDone(false, e.message)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        stopRecording()
        removeBubble()
        mediaProjection?.stop()
        mediaProjection = null
    }
}
