package com.h4ll0.recorder

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import java.io.File
import java.io.FileOutputStream

class ScreenCaptureService : Service() {
    companion object { var instance: ScreenCaptureService? = null }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var mediaRecorder: MediaRecorder? = null
    private var width = 0
    private var height = 0
    private var density = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        startForeground(3, notif())
        @Suppress("DEPRECATION")
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        width = metrics.widthPixels
        height = metrics.heightPixels
        density = metrics.densityDpi
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED) ?: Activity.RESULT_CANCELED
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra("data", Intent::class.java)
            else @Suppress("DEPRECATION") intent?.getParcelableExtra("data")
        if (resultCode == Activity.RESULT_OK && data != null) {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mgr.getMediaProjection(resultCode, data)
        }
        return START_NOT_STICKY
    }

    private fun notif(): Notification {
        val ch = "screencap"
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(ch, "Recorder H4ll0", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(c)
        }
        return NotificationCompat.Builder(this, ch)
            .setContentTitle("Recorder H4ll0 aktif")
            .setContentText("Siap merekam layar")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true).build()
    }

    fun startRecording(onDone: (Boolean, String?) -> Unit) {
        val mp = mediaProjection
        if (mp == null) { onDone(false, "Izin layar belum siap"); return }
        try {
            val file = File(FilesUtil.videosDir(this), "SCR_${System.currentTimeMillis()}.mp4")
            val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else @Suppress("DEPRECATION") MediaRecorder()
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setVideoSize(width, height)
            rec.setVideoFrameRate(30)
            rec.setVideoEncodingBitRate(8_000_000)
            rec.setOutputFile(file.absolutePath)
            rec.prepare()
            virtualDisplay = mp.createVirtualDisplay(
                "H4ll0ScreenRecord", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, rec.surface, null, null
            )
            rec.start()
            mediaRecorder = rec
            onDone(true, null)
        } catch (e: Exception) {
            onDone(false, e.message)
        }
    }

    fun stopRecording() {
        try { mediaRecorder?.stop() } catch (_: Exception) { }
        try { mediaRecorder?.reset() } catch (_: Exception) { }
        mediaRecorder?.release(); mediaRecorder = null
        virtualDisplay?.release(); virtualDisplay = null
    }

    fun takeScreenshot(onDone: (Boolean, String?) -> Unit) {
        val mp = mediaProjection
        if (mp == null) { onDone(false, "Izin layar belum siap"); return }
        try {
            val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            val vd = mp.createVirtualDisplay(
                "H4ll0Screenshot", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.surface, null, null
            )
            reader.setOnImageAvailableListener({ r ->
                val image = r.acquireLatestImage()
                if (image != null) {
                    val plane = image.planes[0]
                    val buffer = plane.buffer
                    val pixelStride = plane.pixelStride
                    val rowStride = plane.rowStride
                    val rowPadding = rowStride - pixelStride * width
                    val bmp = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
                    bmp.copyPixelsFromBuffer(buffer)
                    image.close()
                    val file = File(FilesUtil.photosDir(this), "SS_${System.currentTimeMillis()}.png")
                    FileOutputStream(file).use { out -> bmp.compress(Bitmap.CompressFormat.PNG, 100, out) }
                    vd.release(); reader.close()
                    onDone(true, null)
                } else {
                    vd.release(); reader.close()
                    onDone(false, "Gagal ambil gambar layar")
                }
            }, null)
        } catch (e: Exception) {
            onDone(false, e.message)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        stopRecording()
        mediaProjection?.stop()
        mediaProjection = null
    }
}
