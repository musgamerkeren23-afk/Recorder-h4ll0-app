package com.h4ll0.recorder

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val Red = Color(0xFFE0262E)

@Composable
fun ScreenRecordScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var overlayOk by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    var ready by remember { mutableStateOf(false) }
    var recording by remember { mutableStateOf(false) }
    var seconds by remember { mutableStateOf(0) }
    fun toast(t: String) = Toast.makeText(context, t, Toast.LENGTH_SHORT).show()

    val lOverlay = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        overlayOk = Settings.canDrawOverlays(context)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val svcIntent = Intent(context, ScreenCaptureService::class.java)
                .putExtra("resultCode", result.resultCode)
                .putExtra("data", result.data)
            ContextCompat.startForegroundService(context, svcIntent)
            scope.launch { delay(400); ready = true }
            toast("Bubble aktif! Buka game/app lain, tombol rekam tetap ada di bubble melayang.")
        } else toast("Izin layar ditolak")
    }

    fun requestPermission() {
        val mgr = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        launcher.launch(mgr.createScreenCaptureIntent())
    }

    fun startRec() {
        val svc = ScreenCaptureService.instance
        if (svc == null) { toast("Izin layar belum siap, coba lagi"); return }
        svc.startRecording { ok, err ->
            if (ok) {
                recording = true; seconds = 0
                scope.launch { while (recording) { delay(1000); seconds++ } }
            } else toast("Gagal rekam: $err")
        }
    }
    fun stopRec() {
        ScreenCaptureService.instance?.stopRecording()
        recording = false
        toast("Rekaman layar tersimpan")
    }
    fun shot() {
        val svc = ScreenCaptureService.instance
        if (svc == null) { toast("Izin layar belum siap, coba lagi"); return }
        svc.takeScreenshot { ok, err -> toast(if (ok) "Screenshot tersimpan" else "Gagal: $err") }
    }

    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("Rekam Layar + Suara", fontSize = 20.sp)
        Spacer(Modifier.height(6.dp))
        Text("Setelah aktif, ada bubble melayang di atas app apa pun (termasuk game) buat mulai/stop rekam tanpa buka app ini.", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(20.dp))

        if (!overlayOk) {
            Text("1. Izinkan tampil di atas app lain:", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Button({
                lOverlay.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
            }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Izinkan Bubble") }
        } else if (!ready) {
            Text("2. Izinkan rekam layar:", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            Button({ requestPermission() }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Izinkan Rekam Layar") }
        } else if (recording) {
            val m = seconds / 60; val s = seconds % 60
            Text("● REC %02d:%02d".format(m, s), color = Red, fontSize = 22.sp)
            Spacer(Modifier.height(12.dp))
            Button({ stopRec() }) { Text("Stop Rekam") }
        } else {
            Text("Bubble aktif ✓ (geser ke mana aja di layar)", color = Color(0xFF7CFF8C))
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button({ startRec() }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("● Mulai Rekam") }
                OutlinedButton({ shot() }) { Text("📸 Screenshot") }
            }
        }
    }
}
