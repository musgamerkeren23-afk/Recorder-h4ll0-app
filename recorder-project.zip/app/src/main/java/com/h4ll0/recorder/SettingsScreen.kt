package com.h4ll0.recorder

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Red = Color(0xFFE0262E)

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("rsettings", Context.MODE_PRIVATE) }
    var res by remember { mutableStateOf(prefs.getString("res", "720p") ?: "720p") }
    var audio by remember { mutableStateOf(prefs.getString("audio", "mic") ?: "mic") }

    fun save(key: String, v: String) { prefs.edit().putString(key, v).apply() }

    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("Pengaturan Rekam", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Red)
        Spacer(Modifier.height(20.dp))

        Text("Sumber Audio", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("mic" to "Mic", "none" to "Tanpa suara").forEach { (k, label) ->
                val pick = { audio = k; save("audio", k) }
                if (audio == k) Button(pick) { Text(label) } else OutlinedButton(pick) { Text(label) }
            }
        }
        Text("\"Device Audio\" (suara game digital tanpa lewat mic) belum tersedia — fitur ini butuh pipeline audio khusus. Mic sudah ikut rekam suara game kalau HP gak pakai headset.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))

        Spacer(Modifier.height(20.dp))
        Text("Kualitas Video", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("480p" to "Hemat", "720p" to "720p", "1080p" to "Penuh").forEach { (k, label) ->
                val pick = { res = k; save("res", k) }
                if (res == k) Button(pick) { Text(label) } else OutlinedButton(pick) { Text(label) }
            }
        }
        Text("Resolusi lebih tinggi = file lebih besar & lebih berat buat HP.", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))

        Spacer(Modifier.height(20.dp))
        Text("Orientasi", fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text("Otomatis ikut posisi layar HP saat kamu tap Mulai Rekam.", color = Color.Gray, fontSize = 12.sp)
    }
}
