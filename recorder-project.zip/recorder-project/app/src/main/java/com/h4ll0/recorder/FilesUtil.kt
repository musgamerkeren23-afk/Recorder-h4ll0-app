package com.h4ll0.recorder

import android.content.Context
import android.os.Environment
import java.io.File

object FilesUtil {
    fun allMedia(context: Context): List<File> {
        // Mengambil file dari direktori Pictures, Movies, dan Music
        val photos = context.getExternalFilesDir(Environment.DIRECTORY_PICTURES)?.listFiles() ?: arrayOf()
        val videos = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)?.listFiles() ?: arrayOf()
        val audios = context.getExternalFilesDir(Environment.DIRECTORY_MUSIC)?.listFiles() ?: arrayOf()

        // Perbaikan: Mengubah Array ke List menggunakan toList() agar bisa digabungkan dengan operator +
        val allFiles = photos.toList() + videos.toList() + audios.toList()

        // Perbaikan: Mengurutkan file berdasarkan waktu modifikasi terbaru dan mengembalikan hasilnya
        return allFiles.sortedByDescending { it.lastModified() }
    }
}

