package com.h4ll0.recorder

import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaPlayer
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp // <-- Perbaikan: Import ini ditambahkan agar .sp bisa terbaca
import androidx.core.content.FileProvider
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun GalleryScreen() {
    val context = LocalContext.current
    var files by remember { mutableStateOf(FilesUtil.allMedia(context)) }
    var preview by remember { mutableStateOf<File?>(null) }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var playingFile by remember { mutableStateOf<String?>(null) }
    val fmt = remember { SimpleDateFormat("dd MMM, HH:mm", Locale("id")) }

    DisposableEffect(Unit) { onDispose { player?.release() } }

    preview?.let { f ->
        AlertDialog(onDismissRequest = { preview = null }, confirmButton = { TextButton({ preview = null }) { Text("Tutup") } },
            text = {
                val bmp = remember(f) { BitmapFactory.decodeFile(f.path) }
                if (bmp != null) Image(bmp.asImageBitmap(), null, Modifier.fillMaxWidth())
            })
    }

    if (files.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Belum ada rekaman. Coba tab Kamera atau Mic dulu.", color = Color.Gray)
        }
        return
    }

    LazyColumn(Modifier.fillMaxSize().padding(10.dp)) {
        items(files, key = { it.path }) { f ->
            val isPhoto = f.extension == "jpg"
            val isVideo = f.extension == "mp4"
            val isAudio = f.extension == "m4a"
            Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable {
                when {
                    isPhoto -> preview = f
                    isVideo -> {
                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", f)
                        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        runCatching { context.startActivity(i) }
                    }
                    isAudio -> {
                        if (playingFile == f.path) { player?.release(); player = null; playingFile = null }
                        else {
                            player?.release()
                            player = MediaPlayer().apply {
                                setDataSource(f.path); prepare(); start()
                                setOnCompletionListener { playingFile = null }
                            }
                            playingFile = f.path
                        }
                    }
                }
            }) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(when { isPhoto -> "📷"; isVideo -> "🎬"; isAudio -> if (playingFile == f.path) "⏸" else "🎙"; else -> "📄" }, fontSize = 22.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(f.name, maxLines = 1)
                        Text(fmt.format(Date(f.lastModified())), color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
